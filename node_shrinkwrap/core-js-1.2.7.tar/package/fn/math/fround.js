require('../../modules/es6.math.fround');
module.exports = require('../../modules/$.core').Math.fround;