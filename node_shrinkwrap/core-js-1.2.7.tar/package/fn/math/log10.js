require('../../modules/es6.math.log10');
module.exports = require('../../modules/$.core').Math.log10;