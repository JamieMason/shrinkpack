require('../../modules/core.object.make');
module.exports = require('../../modules/$.core').Object.make;