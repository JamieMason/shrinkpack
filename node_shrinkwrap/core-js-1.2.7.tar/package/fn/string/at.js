require('../../modules/es7.string.at');
module.exports = require('../../modules/$.core').String.at;