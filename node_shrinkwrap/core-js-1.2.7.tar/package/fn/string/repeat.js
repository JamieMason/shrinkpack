require('../../modules/es6.string.repeat');
module.exports = require('../../modules/$.core').String.repeat;