require('../../modules/es6.regexp.split');
module.exports = require('../../modules/$.wks')('split');