require('../../modules/es6.reflect.has');
module.exports = require('../../modules/$.core').Reflect.has;