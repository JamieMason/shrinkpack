require('../../modules/es6.reflect.get-prototype-of');
module.exports = require('../../modules/$.core').Reflect.getPrototypeOf;