require('../modules/core.dict');
module.exports = require('../modules/$.core').Dict;