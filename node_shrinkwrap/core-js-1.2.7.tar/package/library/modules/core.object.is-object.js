var $export = require('./$.export');

$export($export.S + $export.F, 'Object', {isObject: require('./$.is-object')});